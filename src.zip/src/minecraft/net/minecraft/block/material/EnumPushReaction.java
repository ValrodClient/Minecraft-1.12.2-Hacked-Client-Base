package net.minecraft.block.material;

public enum EnumPushReaction
{
    NORMAL,
    DESTROY,
    BLOCK,
    IGNORE,
    PUSH_ONLY;
}
