package me.valrod.client.events;

public class Event {

	public Event() {
		
	}
	
}
