package me.valrod.client.events;

public class EventUpdate extends Event{
	
	public EventUpdate() {
		
	}
	
}
