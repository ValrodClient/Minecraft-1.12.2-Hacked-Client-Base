package me.valrod.client.events;

public class EventRender3D extends Event{
	
	public EventRender3D() {
		
	}
	
}
