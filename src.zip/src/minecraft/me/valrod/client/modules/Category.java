package me.valrod.client.modules;

public enum Category {
	COMBAT,
	PLAYER,
	MOVEMENT,
	WORLD,
	RENDER,
	HUD;
}
